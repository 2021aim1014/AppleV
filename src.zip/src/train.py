import torch
from tqdm import tqdm
from utils.metric import calculate_model_parameters, calculate_metrics, write_to_csv

def train_model(model_name, model, train_loader, val_loader, criterion, optimizer, num_epochs=10, device='cuda'):
    model = model.to(device)

    # Early stopping parameters
    patience = 5
    best_train_loss = float('inf')
    epochs_no_improve = 0

    # Lists to store metrics
    train_losses = []
    val_losses = []
    train_metrics = {"MSE": [], "MAE": [], "R2": []}
    val_metrics = {"MSE": [], "MAE": [], "R2": []}

    for epoch in tqdm(range(num_epochs)):
        # Training phase
        model.train()
        running_loss = 0.0
        y_true_train, y_pred_train = [], []

        for images, labels in train_loader:
            images, labels = images.to(device), labels.to(device)

            # Forward pass
            outputs = model(images)

            # Calculate loss
            loss = criterion(outputs, labels)

            # Backward pass and optimization
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            # Accumulate loss and predictions
            running_loss += loss.item()
            y_true_train.append(labels)
            y_pred_train.append(outputs)

        # Normalize training loss
        train_loss = running_loss / len(train_loader)
        train_losses.append(train_loss)

        # Calculate training metrics
        y_true_train = torch.cat(y_true_train, dim=0)
        y_pred_train = torch.cat(y_pred_train, dim=0)
        mse, mae, r2 = calculate_metrics(y_true_train, y_pred_train)
        train_metrics["MSE"].append(mse)
        train_metrics["MAE"].append(mae)
        train_metrics["R2"].append(r2)

        print(f"Epoch [{epoch+1}/{num_epochs}], Training Loss: {train_loss:.4f}, MSE: {mse:.4f}, MAE: {mae:.4f}, R2: {r2:.4f}")

        # Early stopping logic
        if train_loss < best_train_loss:
            best_train_loss = train_loss
            epochs_no_improve = 0
            # Optionally save the best model
            torch.save(model.state_dict(), "best_model.pth")
        else:
            epochs_no_improve += 1

        if epochs_no_improve == patience:
            print(f"Early stopping triggered. No improvement for {patience} epochs.")

        if epoch % 10 == 9:
            # Validation phase
            model.eval()
            val_loss = 0.0
            y_true_val, y_pred_val = [], []

            with torch.no_grad():
                for images, labels in val_loader:
                    images, labels = images.to(device), labels.to(device)

                    # Forward pass
                    outputs = model(images)

                    # Calculate loss
                    loss = criterion(outputs, labels)

                    # Accumulate validation loss and predictions
                    val_loss += loss.item()
                    y_true_val.append(labels)
                    y_pred_val.append(outputs)
                    break

            # Normalize validation loss
            val_loss /= len(val_loader)
            val_losses.append(val_loss)

            # Calculate validation metrics
            y_true_val = torch.cat(y_true_val, dim=0)
            y_pred_val = torch.cat(y_pred_val, dim=0)
            mse, mae, r2 = calculate_metrics(y_true_val, y_pred_val)
            val_metrics["MSE"].append(mse)
            val_metrics["MAE"].append(mae)
            val_metrics["R2"].append(r2)

            print(f"Epoch [{epoch+1}/{num_epochs}], Validation Loss: {val_loss:.4f}, MSE: {mse:.4f}, MAE: {mae:.4f}, R2: {r2:.4f}")