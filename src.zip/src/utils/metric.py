import torch
import pandas as pd
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score

# Function to calculate metrics
def calculate_metrics(y_true, y_pred):
    y_true = y_true.detach().cpu().numpy()
    y_pred = y_pred.detach().cpu().numpy()
    mse = mean_squared_error(y_true, y_pred)
    mae = mean_absolute_error(y_true, y_pred)
    r2 = r2_score(y_true, y_pred)
    return mse, mae, r2

def write_to_csv(model_name, num_epochs, train_losses, val_losses, train_metrics, val_metrics, total_params, trainable_params, non_trainable_params):
    # Save results to CSV
    results = {
        "Epoch": list(range(1, num_epochs + 1)),
        "Train Loss": train_losses,
        "Train MSE": train_metrics["MSE"],
        "Train MAE": train_metrics["MAE"],
        "Train R2": train_metrics["R2"],
    }
    
    # Add parameter counts as additional rows (repeated across all rows for clarity)
    results["Total Params"] = [total_params] * num_epochs
    results["Trainable Params"] = [trainable_params] * num_epochs
    results["Non-trainable Params"] = [non_trainable_params] * num_epochs

    results["Val Loss"] = val_losses * num_epochs
    results["Val MSE"] = val_metrics["MSE"] * num_epochs
    results["Val MAE"] = val_metrics["MAE"] * num_epochs
    results["Val R2"] = val_metrics["R2"] * num_epochs

    df = pd.DataFrame(results)
    df.to_csv(f"results/{model_name}.csv", index=False)
    print("Results saved to 'training_results_with_params.csv'")

def calculate_model_parameters(model):
    # Count model parameters
    total_params = sum(p.numel() for p in model.parameters())
    trainable_params = sum(p.numel() for p in model.parameters() if p.requires_grad)
    non_trainable_params = total_params - trainable_params

    print(f"Total parameters: {total_params}")
    print(f"Trainable parameters: {trainable_params}")
    print(f"Non-trainable parameters: {non_trainable_params}")
    return total_params, trainable_params, non_trainable_params