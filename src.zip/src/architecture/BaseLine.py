import torch
import pandas as pd
import torch.nn.functional as F

# Load CSV
labels_df = pd.read_csv('../../dataset/AppleV_intrinsic.csv')
label_col = ['TSS_brix', 'Firmness', 'Titerabile acid percentage']   # change this if your column name differs
mean_value = labels_df[label_col].mean()
labels_df[label_col] = labels_df[label_col] - mean_value

# Convert columns to tensors
tss_labels = torch.tensor(labels_df['TSS_brix'].values, dtype=torch.float32)
firmness_labels = torch.tensor(labels_df['Firmness'].values, dtype=torch.float32)
titerabile_labels = torch.tensor(labels_df['Titerabile acid percentage'].values, dtype=torch.float32)


# Calculate average values
tss_mean = torch.mean(tss_labels)
firm_mean = torch.mean(firmness_labels)
titt_mean = torch.mean(titerabile_labels)

# print mean values
print(f"Average TSS (Brix): {tss_mean:.4f}")
print(f"Average Firmness: {firm_mean:.4f}")
print(f"Average Titerabile Acid Percentage: {titt_mean:.4f}")


# Example 1: Mean Squared Error (Regression task)
mse_loss = F.mse_loss(tss_labels, tss_mean.expand_as(tss_labels))
print(f"MSE Loss: {mse_loss:.4f}")

# Example 2: Mean Absolute Error
mae_loss = F.l1_loss(tss_labels, tss_mean.expand_as(tss_labels))
print(f"MAE Loss: {mae_loss:.4f}")
